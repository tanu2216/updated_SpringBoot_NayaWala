package com.cg.wallet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WallletApplicationByOllieDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(WallletApplicationByOllieDemoApplication.class, args);
	}

}
