package com.cg.wallet.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.wallet.bean.Customer;

@Repository
public interface CustomerRepoo extends JpaRepository<Customer, String> {

}
