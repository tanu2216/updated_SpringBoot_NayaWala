package com.cg.wallet.service;

import com.cg.wallet.bean.Customer;

public interface CustomerSservice {

	public Customer addCustomer (Customer customer);
	
	public Customer show(String mobileNumber);
	
	public Customer deposit(String mobileNumber, float amount);
	
	public Customer withdraw(String mobileNumber, float amount);
	
	public String fundsTransfer(String source, String dest, float amount);
	
	
}
