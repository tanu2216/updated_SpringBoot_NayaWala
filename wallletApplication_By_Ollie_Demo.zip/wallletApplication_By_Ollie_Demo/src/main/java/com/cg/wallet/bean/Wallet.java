package com.cg.wallet.bean;

import javax.persistence.Embeddable;

@Embeddable
public class Wallet {

	private float balance;

	public float getBalance() {
		return balance;
	}

	public void setBalance(float balance) {
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "Wallet [balance=" + balance + "]";
	}
	
}
