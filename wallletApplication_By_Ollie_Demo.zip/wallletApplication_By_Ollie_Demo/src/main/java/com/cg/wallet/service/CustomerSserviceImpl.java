package com.cg.wallet.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.wallet.bean.Customer;
import com.cg.wallet.bean.Wallet;
import com.cg.wallet.repo.CustomerRepoo;
 
@Service
public class CustomerSserviceImpl implements CustomerSservice {

	@Autowired
	CustomerRepoo repo;
	
	@Override
	public Customer addCustomer(Customer customer) {
	
		repo.save(customer);
		return customer;
	}

	@Override
	public Customer show(String mobileNumber) {
	
		return repo.findById(mobileNumber).get();
		
	}

	@Override
	public Customer deposit(String mobileNumber, float amount) {

		Customer customer=repo.findById(mobileNumber).get();
		float bal=customer.getWallet().getBalance()+amount;
		customer.getWallet().setBalance(bal);
		repo.save(customer);
		return customer;
	}

	@Override
	public Customer withdraw(String mobileNumber, float amount) {

		Customer customer=repo.findById(mobileNumber).get();
		float bal=customer.getWallet().getBalance()-amount;
		customer.getWallet().setBalance(bal);
		repo.save(customer);
		return customer;

	}

	@Override
	public String fundsTransfer(String source, String dest, float amount) {

		return null;
	}

}
